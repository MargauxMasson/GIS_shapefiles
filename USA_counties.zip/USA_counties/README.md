Shapefiles USA counties

Original files from https://gadm.org/data.html

Format: State_county
